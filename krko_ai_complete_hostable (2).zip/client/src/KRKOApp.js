
import React, { useState } from "react";

export default function KRKOApp() {
  const [response, setResponse] = useState("");
  const [query, setQuery] = useState("");

  const askAI = async () => {
    const res = await fetch("https://krko-server.onrender.com/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: query }),
    });
    const data = await res.json();
    setResponse(data.reply);
  };

  return (
    <div style={{ padding: 20, backgroundColor: '#000', color: '#fff', minHeight: '100vh' }}>
      <h1>KRKO.AI</h1>
      <p>Talk to AI, search anything, generate images</p>
      <input
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        style={{ width: 300, padding: 8 }}
        placeholder="Ask something..."
      />
      <button onClick={askAI} style={{ marginLeft: 10, padding: 8 }}>Send</button>
      <div style={{ marginTop: 20 }}>{response}</div>
    </div>
  );
}
